async function mainAnimation(){
	
	return 0;
}
